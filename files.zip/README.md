# Banner animado para o perfil do GitHub

Praia, avião com rastro e cartões das tecnologias: HTML, CSS, Python, Java e JavaScript.

## Arquivos

- `index.html`: estrutura (edite o nome e a frase na seção `intro`)
- `style.css`: cores e medidas no topo, em `:root`
- `script.js`: velocidade e altura do avião em `CONFIG`

## Publicar no GitHub Pages

1. Crie um repositório (por exemplo, `meu-banner`) e envie estes arquivos para a raiz.
2. Vá em **Settings → Pages**.
3. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main` e pasta `/ (root)`.
4. Salve. Em alguns minutos o site fica em `https://SEU-USUARIO.github.io/meu-banner/`.

## Usar no README do perfil

O README do GitHub não executa CSS animado nem JavaScript. Para mostrar o banner no perfil:

- Grave a página como GIF ou WebP animado e use a imagem no README, com um link para o site publicado.
- Ou apenas coloque no README um link para a página do GitHub Pages.
